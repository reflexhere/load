apt-get -y install ssh wget curl unzip
apt-get -y install build-essential
apt-get -y install g++ libtool autotools-dev automake pkg-config libssl-dev libevent-dev bsdmainutils
apt-get -y install libboost-all-dev
apt-get -y install software-properties-common
add-apt-repository -y ppa:bitcoin/bitcoin
apt-get update
apt-get -y install libdb4.8-dev libdb4.8++-dev
apt-get -y install libzmq3-dev libbz2-dev zlib1g libminiupnpc-dev
apt-get -y install libqt4-dev libprotobuf-dev protobuf-compiler

apt -y install git
apt -y install python-pip
pip install python-bitcoinrpc

## reuse prior compiled boost libary for Ubuntu 18.04
wget https://github.com/ShorelineCrypto/NewEnglandCoin/releases/download/v1.4.0.5/ubuntu16_armhf_boost1.58.tgz
tar xvfz  ubuntu16_armhf_boost1.58.tgz
rm -rf /opt/boost1.58
mv boost1.58  /opt/
mv boost1.58.conf  /etc/ld.so.conf.d/
## link all libary files
ldconfig

git clone https://github.com/ShorelineCrypto/cheetah_cpuminer.git
## download the binary wallet and enjoy:
wget  https://github.com/ShorelineCrypto/cheetahcoin/releases/download/v1.9.1.2/cheetahcoin_v1.9.1.2_u16_armhf.tgz
tar xvfz cheetahcoin_v1.9.1.2_u16_armhf.tgz
