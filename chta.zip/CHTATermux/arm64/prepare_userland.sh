## Productivity tools
apt-get update
apt -y install ssh
apt -y install wget
apt -y install screen
apt -y install vim
apt -y install nano

## fix proc and permission errors causing top ps to fail, workaround
## toybox-aarch64 workaround provided at: 
## https://github.com/CypherpunkArmory/UserLAnd/issues/87

wget http://landley.net/toybox/downloads/binaries/latest/toybox-aarch64
chmod a+rx toybox-aarch64
mv toybox-aarch64 /usr/local/bin/

cat >> ~/.bashrc  << EOF

alias top="toybox-aarch64 top"
alias ps="toybox-aarch64 ps"
alias uptime="toybox-aarch64 uptime"
alias reset="toybox-aarch64 reset"

EOF
