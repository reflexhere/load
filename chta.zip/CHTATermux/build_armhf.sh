cd armhf && chmod +x prepare_userland.sh && chmod +x prepare_neng.sh && bash prepare_userland.sh && bash prepare_neng.sh
