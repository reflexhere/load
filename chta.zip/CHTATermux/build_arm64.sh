cd arm648 && chmod +x prepare_userland.sh && chmod +x prepare_neng.sh && bash prepare_userland.sh && prepare_neng.sh
